
"use client";

import { motion, useAnimationControls } from "framer-motion";
import { useEffect } from "react";

export default function Page() {
  const controls = useAnimationControls();

  useEffect(() => {
    controls.start({
      scale: [1, 1.2, 1],
      transition: {
        repeat: Infinity,
        repeatType: "loop",
        duration: 0.8,
        ease: "easeInOut",
      },
    });
  }, [controls]);

  return (
    <div className="flex items-center justify-center h-screen bg-gradient-to-br from-purple-800 via-pink-600 to-red-500">
      <motion.svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 24 24"
        className="w-40 h-40 drop-shadow-[0_0_15px_rgba(255,0,0,0.7)]"
        initial="hidden"
        animate={controls}
      >
        <motion.path
          d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 
             2 8.5 2 6 3.5 4 6 4c1.74 0 3.41 1.01 
             4 2.09C10.59 5.01 12.26 4 14 4c2.5 0 
             4 2 4 4.5 0 3.78-3.4 6.86-8.55 
             11.54L12 21.35z"
          fill="transparent"
          stroke="red"
          strokeWidth="2"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 2 }}
        />
      </motion.svg>
    </div>
  );
}
